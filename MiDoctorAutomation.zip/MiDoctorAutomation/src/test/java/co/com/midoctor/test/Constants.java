package co.com.midoctor.test;

public class Constants {
    public static final String PATIENTNAME = "Gabriel Ernesto",
    PATIENTLASTNAME = "Blanco Larrota",
    PATIENTID = "1075680601",
    PATIENTEMAIL = "geblarot96@gmail.com",
    DOCTORSEARCH = "Lina Jimeno",
    COMMONPASSWORD = "123456aB!",
    PATIENTCITY = "Bogotá",
    PATIENTPHONE = "3999999999";
}
